const http = require("node:http");
const fs = require("node:fs");
const path = require("node:path");
const { buildCommandView } = require("./src/decisionEngine");

const demoSignals = require("./demo-data.json");
const server = http.createServer((req,res)=>{
  if(req.url === "/api/command"){
    res.writeHead(200,{"Content-Type":"application/json"});
    return res.end(JSON.stringify(buildCommandView(demoSignals)));
  }
  const file = req.url === "/" ? "index.html" : req.url.slice(1);
  const safe = path.join(__dirname,file);
  if(!safe.startsWith(__dirname) || !fs.existsSync(safe)){res.writeHead(404);return res.end("Not found");}
  const ext=path.extname(safe);
  res.writeHead(200,{"Content-Type":ext===".html"?"text/html":ext===".js"?"text/javascript":"text/plain"});
  fs.createReadStream(safe).pipe(res);
});
server.listen(process.env.PORT || 3000,()=>console.log("247 Command Core running on http://localhost:"+(process.env.PORT||3000)));
