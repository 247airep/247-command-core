const test=require("node:test"); const assert=require("node:assert/strict");
const {scoreSignal,buildCommandView}=require("../src/decisionEngine");
test("higher economic/urgent signal ranks first",()=>{
 const rows=[{exposure:1000,urgency:1,confidence:.5,ageHours:1},{exposure:10000,urgency:5,confidence:.9,ageHours:24}];
 assert.equal(buildCommandView(rows)[0].exposure,10000);
});
test("score is deterministic",()=>{const s={exposure:5000,urgency:3,confidence:.8,ageHours:12};assert.equal(scoreSignal(s),42)});
