# 24/7 Command Core

**Complexity In → Decision Clarity Out**

Command Core is the first working foundation for 24/7 AI Rep's internal operating layer. It converts signals from multiple business domains into a prioritized decision queue rather than another dashboard full of metrics.

## V0 workflow

`SIGNAL → NORMALIZE → SCORE → PRIORITIZE → EVIDENCE → DECISION → ACTION → OUTCOME`

V0 includes:
- a real Node HTTP endpoint at `/api/command`
- deterministic prioritization logic
- demo signal data across project profit, revenue recovery, workflow reliability, and lead operations
- evidence counts, uncertainty, confidence, potential exposure, and recommended investigation
- a decision-first responsive UI
- automated Node tests
- GitHub Actions test workflow

## Run

```bash
npm start
```

Open `http://localhost:3000`.

## Test

```bash
npm test
```

## Product principles

1. Decision clarity beats information volume.
2. Evidence and uncertainty stay visible.
3. AI/model output must not silently become fact.
4. Human decisions and overrides should be captured.
5. Connectors are replaceable; the decision layer is the asset.
6. Potential financial exposure is not presented as realized savings.

## Demo-data notice

All companies, signals, financial values, and incidents in this repository are fictional/illustrative. They demonstrate system behavior and are not claimed client outcomes.

## Next build

V1 adds persistent event/decision storage, the Workflow Black Box event ledger, action/outcome tracking, and a synthetic business generator for repeatable reliability testing.
