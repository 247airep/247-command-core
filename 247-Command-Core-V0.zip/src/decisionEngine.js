function scoreSignal(s) {
  const impact = Math.min(40, Math.round((s.exposure || 0) / 500));
  const urgency = Math.min(25, s.urgency * 5);
  const confidence = Math.round(s.confidence * 20);
  const age = Math.min(15, Math.floor(s.ageHours / 12));
  return impact + urgency + confidence + age;
}
function buildCommandView(signals){
  return signals.map(s=>({...s,score:scoreSignal(s)})).sort((a,b)=>b.score-a.score);
}
module.exports={scoreSignal,buildCommandView};
